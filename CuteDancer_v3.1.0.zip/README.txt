CuteDancer <dev version>

From Unity's top menu select "Tools" -> "CuteDancer Setup" and follow instructions.

For more information visit:

https://github.com/Krysiek/CuteDancer